# Encryption & Decryption Tool
This project demonstrates three encryption algorithms using cryptographic techniques. The supported algorithms include **OTP (One-Time Pad)**, **3DES (Triple DES)**, and **AES (Advanced Encryption Standard)**. It uses **Django** as the web framework to create an API for encryption and decryption operations.

